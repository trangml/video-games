# Video-Game-Final-Project

ECE_4525: Final Project: Island Explorer
Author: Matthew Luu Trang & Nathan Moeliono
Date: 10/29/2021

This assignment contains the code for our final project, Island Explorer, which is a top down
RPG rougelike game. The player must navigate multiple islands and defeat enemies to collect
materials to craft new tools to help him go to other islands. The game is played using the arrow
keys and mouse. The keyboard buttons 1-9 are used to change the item that the character is
holding, and the z button is used to apply the effect of the item, while the x button is used to
throw or place the item.
